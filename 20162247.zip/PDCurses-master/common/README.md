PDCurses common files
=====================

This directory is for files which are platform-specific, yet shared by
more than one platform, in contrast to the "common core" in ../pdcurses.
